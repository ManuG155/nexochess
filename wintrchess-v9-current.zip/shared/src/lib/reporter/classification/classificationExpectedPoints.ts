import {
    PieceColour
} from "@/constants/PieceColour";

import Evaluation from
    "@/types/game/position/Evaluation";

import {
    getExpectedPointsLoss
} from "../expectedPoints";

/*
 * ============================================================
 * CLASSIFICATION EXPECTED POINTS V1
 * ============================================================
 *
 * This calibration layer is used ONLY by the standard move classifier:
 *
 *   Excellent / Good / Inaccuracy / Mistake / Blunder
 *
 * Accuracy V2 continues to use the historical Expected Points model
 * directly, so its current calibration remains frozen.
 *
 * Miss V4 also remains untouched and continues to use its contextual,
 * rating-aware A -> B -> C model.
 *
 * Why does this layer exist?
 *
 * WintrChess's historical Expected Points curve systematically produced
 * too many very small losses in our anchor games. Applying the public
 * 0.02 / 0.05 / 0.10 / 0.20 classification thresholds directly to that
 * curve therefore inflated Excellent and compressed Good/Inaccuracy/
 * Mistake.
 *
 * Instead of changing Accuracy or moving the public classification
 * thresholds, we map the raw WintrChess EP loss onto a dedicated
 * classification loss scale.
 *
 * The map is monotonic and continuous. Severe losses are deliberately
 * changed much less than small and medium losses so we do not create a
 * large number of new Blunders.
 */

interface CalibrationAnchor {
    raw: number;
    calibrated: number;
}

/*
 * Empirical anchors for Classification V5.
 *
 * Interpretation:
 *
 * raw WintrChess loss 0.012 -> classification loss 0.020
 * raw WintrChess loss 0.035 -> classification loss 0.050
 * raw WintrChess loss 0.075 -> classification loss 0.100
 * raw WintrChess loss 0.200 -> classification loss 0.200
 *
 * Therefore the standard public-facing category boundaries remain:
 *
 * <= 0.02  Excellent
 * <= 0.05  Good
 * <= 0.10  Inaccuracy
 * <= 0.20  Mistake
 * >  0.20  Blunder
 */
const CALIBRATION_ANCHORS:
    CalibrationAnchor[] = [

    {
        raw: 0,
        calibrated: 0
    },

    {
        raw: 0.012,
        calibrated: 0.020
    },

    {
        raw: 0.035,
        calibrated: 0.050
    },

    {
        raw: 0.075,
        calibrated: 0.100
    },

    {
        raw: 0.200,
        calibrated: 0.200
    },

    {
        raw: 1,
        calibrated: 1
    }
];

function clamp(
    value: number,
    min: number,
    max: number
) {
    return Math.min(
        max,
        Math.max(
            min,
            value
        )
    );
}

function interpolate(
    value: number,
    left: CalibrationAnchor,
    right: CalibrationAnchor
) {
    if (
        right.raw == left.raw
    ) {
        return right.calibrated;
    }

    const progress =
        (
            value
            - left.raw
        )
        /
        (
            right.raw
            - left.raw
        );

    return left.calibrated
        + progress
        * (
            right.calibrated
            - left.calibrated
        );
}

/**
 * Convert a raw WintrChess Expected Points loss to the dedicated
 * Classification V5 loss scale.
 */
export function calibrateClassificationExpectedPointsLoss(
    rawLoss: number
) {
    const safeLoss =
        clamp(
            rawLoss,
            0,
            1
        );

    for (
        let index = 1;
        index < CALIBRATION_ANCHORS.length;
        index++
    ) {
        const left =
            CALIBRATION_ANCHORS[
                index - 1
            ];

        const right =
            CALIBRATION_ANCHORS[
                index
            ];

        if (
            safeLoss
            <= right.raw
        ) {
            return interpolate(
                safeLoss,
                left,
                right
            );
        }
    }

    return safeLoss;
}

/**
 * Expected Points loss used exclusively for standard move
 * classifications.
 *
 * IMPORTANT:
 * No rating is passed to getExpectedPointsLoss here. This intentionally
 * starts from the stable historical WintrChess EP curve, then applies the
 * isolated Classification V5 calibration above.
 */
export function getClassificationExpectedPointsLoss(
    previousEvaluation: Evaluation,
    currentEvaluation: Evaluation,
    moveColour: PieceColour
) {
    const rawLoss =
        getExpectedPointsLoss(
            previousEvaluation,
            currentEvaluation,
            moveColour
        );

    return calibrateClassificationExpectedPointsLoss(
        rawLoss
    );
}
