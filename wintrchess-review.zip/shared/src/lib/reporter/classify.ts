import {
    WHITE
} from "chess.js";

import ReportOptions from
    "./types/AnalysisOptions";

import {
    StateTreeNode
} from "@/types/game/position/StateTreeNode";

import {
    Classification
} from "@/constants/Classification";

import {
    extractPreviousStateTreeNode,
    extractCurrentStateTreeNode
} from "./utils/extractNode";

import {
    getOpeningName
} from "./utils/opening";

import {
    pointLossClassify
} from "./classification/pointLoss";

import {
    considerMissClassification
} from "./classification/miss";

import {
    considerBrilliantClassification
} from "./classification/brilliant";

import {
    considerCriticalClassification
} from "./classification/critical";


/*
 * ============================================================
 * THEORY DETECTION V2
 * ============================================================
 */


function isStillInOpeningTheory(
    node:
        StateTreeNode
) {

    /*
     * La posición actual
     * debe pertenecer
     * al libro.
     */
    const currentOpening =

        getOpeningName(
            node.state.fen
        );


    if (
        !currentOpening
    ) {

        return false;
    }


    /*
     * Buscamos cualquier posición
     * anterior fuera del libro.
     *
     * Una vez existe
     * la primera desviación:
     *
     * nunca más volvemos
     * a clasificar Book.
     */

    let ancestor =

        node.parent;


    while (
        ancestor
    ) {

        if (
            ancestor
                .state
                .move
        ) {

            const ancestorOpening =

                ancestor
                    .state
                    .opening

                ??

                getOpeningName(

                    ancestor
                        .state
                        .fen

                );


            if (
                !ancestorOpening
            ) {

                return false;
            }

        }


        ancestor =
            ancestor.parent;

    }


    return true;
}


/*
 * ============================================================
 * MAIN CLASSIFIER V2
 * ============================================================
 */


export function classify(
    node:
        StateTreeNode,

    options?:
        ReportOptions
) {

    if (
        !node.parent
    ) {

        throw new Error(
            "no parent node exists to compare with."
        );
    }


    const previous =

        extractPreviousStateTreeNode(
            node.parent
        );


    const current =

        extractCurrentStateTreeNode(
            node
        );


    if (

        !previous

        ||

        !current

    ) {

        throw new Error(
            "information missing from current or previous node."
        );
    }


    const opts = {

        includeBrilliant:

            options
                ?.includeBrilliant

            ?? true,


        includeCritical:

            options
                ?.includeCritical

            ?? true,


        includeTheory:

            options
                ?.includeTheory

            ?? true,


        whiteRating:

            options
                ?.whiteRating,


        blackRating:

            options
                ?.blackRating

    };


    /*
     * Rating del jugador
     * que acaba de realizar
     * la jugada actual.
     */

    const playerRating =

        current
            .playedMove
            .color

        == WHITE

            ? opts
                .whiteRating

            : opts
                .blackRating;


    /*
     * ========================================================
     * 1. FORCED
     * ========================================================
     */

    if (

        previous
            .board
            .moves()
            .length

        <= 1

    ) {

        return Classification.FORCED;
    }


    /*
     * ========================================================
     * 2. THEORY
     * ========================================================
     */

    if (

        opts
            .includeTheory

        &&

        isStillInOpeningTheory(
            node
        )

    ) {

        return Classification.THEORY;
    }


    /*
     * ========================================================
     * 3. CHECKMATE
     * ========================================================
     */

    if (

        current
            .board
            .isCheckmate()

    ) {

        return Classification.BEST;
    }


    /*
     * ========================================================
     * 4. BASE CLASSIFICATION
     * ========================================================
     */


    const topMovePlayed =

        previous
            .topMove
            .san

        ==

        current
            .playedMove
            .san;


    /*
     * Best:
     *
     * - top engine move;
     *
     * O
     *
     * - prácticamente idéntica
     *   en Expected Points.
     *
     *
     * El segundo caso
     * lo controla pointLossClassify().
     */

    let classification =

        topMovePlayed

            ? Classification.BEST

            : pointLossClassify(
                previous,
                current
            );


    /*
     * ========================================================
     * 5. MISS
     * ========================================================
     *
     * Miss se calcula
     * con contexto A → B → C.
     *
     * El propio detector evita
     * convertir en Miss
     * una catástrofe autogenerada.
     */

    if (

        considerMissClassification(

            node,

            playerRating

        )

    ) {

        classification =
            Classification.MISS;

    }


    /*
     * ========================================================
     * 6. GREAT
     * ========================================================
     */

    if (

        classification
        != Classification.MISS

        &&

        opts
            .includeCritical

        &&

        (

            classification
            == Classification.BEST

            ||

            classification
            == Classification.EXCELLENT

        )

        &&

        considerCriticalClassification(
            previous,
            current
        )

    ) {

        classification =
            Classification.CRITICAL;

    }


    /*
     * ========================================================
     * 7. BRILLIANT
     * ========================================================
     */

    const brilliantEligible =

        classification
        == Classification.BEST

        ||

        classification
        == Classification.EXCELLENT

        ||

        classification
        == Classification.CRITICAL;


    if (

        classification
        != Classification.MISS

        &&

        opts
            .includeBrilliant

        &&

        brilliantEligible

        &&

        considerBrilliantClassification(
            previous,
            current
        )

    ) {

        classification =
            Classification.BRILLIANT;

    }


    return classification;
}