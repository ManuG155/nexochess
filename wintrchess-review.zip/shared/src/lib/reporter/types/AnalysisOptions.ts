interface AnalysisOptions {

    includeBrilliant?:
        boolean;

    includeCritical?:
        boolean;

    includeTheory?:
        boolean;


    /*
     * Rating online del jugador
     * correspondiente a esta partida.
     *
     * Se utilizará para adaptar
     * determinados umbrales contextuales,
     * especialmente Miss.
     */
    whiteRating?:
        number;

    blackRating?:
        number;

}


export default AnalysisOptions;