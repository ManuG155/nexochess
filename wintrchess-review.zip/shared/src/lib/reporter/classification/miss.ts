import {
    StateTreeNode
} from "@/types/game/position/StateTreeNode";

import Evaluation from
    "@/types/game/position/Evaluation";

import PieceColour from
    "@/constants/PieceColour";

import {
    getTopEngineLine
} from "@/types/game/position/EngineLine";

import {
    getExpectedPoints
} from "../expectedPoints";


/*
 * ============================================================
 * MISS DETECTOR V2
 * ============================================================
 *
 *
 * Analizamos:
 *
 * A = antes del error rival
 *
 * B = después del error rival
 *     aparece una oportunidad
 *
 * C = después de nuestra respuesta
 *
 *
 * A
 * ↓ rival falla
 * B
 * ↓ jugador no castiga
 * C
 *
 *
 * Un Miss ocurre cuando:
 *
 * 1. El rival nos concede
 *    una mejora significativa.
 *
 * 2. Esa mejora crea
 *    una oportunidad objetivamente
 *    muy fuerte.
 *
 * 3. Nuestra respuesta desperdicia
 *    una parte importante
 *    de la oportunidad.
 *
 *
 * A diferencia de V1:
 *
 * - NO exigimos EP_C > 0.30;
 *
 * - NO usamos retention <= 0.35
 *   como condición binaria;
 *
 * - distinguimos un Miss
 *   de un Blunder autodestructivo;
 *
 * - el concepto de posición
 *   "ganadora" se adapta
 *   ligeramente al rating.
 */


/*
 * ============================================================
 * GENERIC UTILITY
 * ============================================================
 */


function clamp(
    value: number,
    min: number,
    max: number
) {

    return Math.min(

        max,

        Math.max(
            min,
            value
        )

    );
}


/*
 * ============================================================
 * RATING-AWARE WINNING THRESHOLD
 * ============================================================
 *
 *
 * Nuestro Expected Points actual
 * no incorpora directamente
 * la fuerza del jugador.
 *
 * Compensamos parcialmente
 * adaptando el umbral necesario
 * para considerar que existe
 * una oportunidad ganadora.
 *
 *
 * Jugadores de rating bajo:
 *
 * necesitan una ventaja algo
 * más clara para considerar
 * la posición prácticamente ganadora.
 *
 *
 * Jugadores fuertes:
 *
 * pueden convertir posiciones
 * menos dominantes.
 *
 *
 * Aproximadamente:
 *
 * Elo 700  -> ~0.765
 *
 * Elo 1400 -> ~0.740
 *
 * Elo 2000 -> ~0.719
 *
 * Elo 2800 -> ~0.705
 *
 *
 * No es una fórmula oficial.
 */


function getWinningExpectedPointsThreshold(
    rating?: number
) {

    const safeRating =

        clamp(

            rating
            ?? 1200,

            100,

            3000

        );


    const strengthFactor =

        1

        /

        (

            1

            +

            Math.exp(

                -(
                    safeRating
                    - 1400
                )

                / 500

            )

        );


    return (

        0.78

        -

        (
            0.08

            *

            strengthFactor
        )

    );
}


/*
 * ============================================================
 * EXPECTED POINTS FROM PLAYER PERSPECTIVE
 * ============================================================
 */


function getExpectedPointsForColour(
    evaluation:
        Evaluation,

    colour:
        PieceColour
) {

    const whiteExpectedPoints =

        getExpectedPoints(

            evaluation,

            {
                moveColour:
                    colour
            }

        );


    if (
        colour
        == PieceColour.WHITE
    ) {

        return whiteExpectedPoints;
    }


    return (

        1

        -

        whiteExpectedPoints

    );
}


/*
 * ============================================================
 * MAIN MISS DETECTOR
 * ============================================================
 */


export function considerMissClassification(
    node:
        StateTreeNode,

    playerRating?:
        number
) {

    /*
     * C
     *
     * Posición después
     * de nuestra respuesta.
     */
    const afterResponse =
        node;


    /*
     * B
     *
     * Posición después
     * del movimiento rival.
     *
     * Aquí aparece
     * la oportunidad.
     */
    const afterOpponentMove =

        node.parent;


    /*
     * A
     *
     * Posición antes
     * de la jugada rival.
     */
    const beforeOpponentMove =

        afterOpponentMove
            ?.parent;


    const playerColour =

        node
            .state
            .moveColour;


    if (

        !playerColour

        ||

        !afterOpponentMove

        ||

        !beforeOpponentMove

    ) {

        return false;
    }


    /*
     * Comprobamos que B
     * realmente fue producido
     * por una jugada del rival.
     */
    if (

        !afterOpponentMove
            .state
            .move

        ||

        afterOpponentMove
            .state
            .moveColour
        == playerColour

    ) {

        return false;
    }


    const beforeLine =

        getTopEngineLine(

            beforeOpponentMove
                .state
                .engineLines

        );


    const opportunityLine =

        getTopEngineLine(

            afterOpponentMove
                .state
                .engineLines

        );


    const responseLine =

        getTopEngineLine(

            afterResponse
                .state
                .engineLines

        );


    if (

        !beforeLine

        ||

        !opportunityLine

        ||

        !responseLine

    ) {

        return false;
    }


    /*
     * Expected Points desde
     * el punto de vista
     * del jugador analizado.
     */

    const epA =

        getExpectedPointsForColour(

            beforeLine
                .evaluation,

            playerColour

        );


    const epB =

        getExpectedPointsForColour(

            opportunityLine
                .evaluation,

            playerColour

        );


    const epC =

        getExpectedPointsForColour(

            responseLine
                .evaluation,

            playerColour

        );


    /*
     * ========================================================
     * STEP 1
     * OPPORTUNITY CREATED
     * ========================================================
     */


    const opportunityGain =

        epB

        -

        epA;


    /*
     * V1 utilizaba 0.15.
     *
     * Lo bajamos ligeramente
     * porque estaba perdiendo
     * oportunidades reales.
     */
    if (

        opportunityGain

        < 0.10

    ) {

        return false;
    }


    /*
     * La oportunidad debe llevarnos
     * a una posición suficientemente
     * fuerte como para que tenga sentido
     * hablar de oportunidad ganadora.
     */

    const winningThreshold =

        getWinningExpectedPointsThreshold(
            playerRating
        );


    if (

        epB

        < winningThreshold

    ) {

        return false;
    }


    /*
     * ========================================================
     * STEP 2
     * OPPORTUNITY WASTED
     * ========================================================
     */


    const opportunityLost =

        epB

        -

        epC;


    /*
     * También relajamos ligeramente
     * el antiguo 0.15.
     */
    if (

        opportunityLost

        < 0.10

    ) {

        return false;
    }


    /*
     * ========================================================
     * STEP 3
     * DISTINGUISH MISS FROM BLUNDER
     * ========================================================
     *
     *
     * Caso Miss:
     *
     * A = 0.20
     * B = 0.80
     * C = 0.25
     *
     * Hemos desaprovechado
     * una oportunidad enorme,
     * pero no hemos empeorado
     * mucho respecto a A.
     *
     *
     * Caso Blunder:
     *
     * A = 0.50
     * B = 0.90
     * C = 0.00
     *
     * No solo perdimos
     * la oportunidad:
     *
     * además destruimos
     * nuestra posición original.
     */


    const selfInflictedLoss =

        epA

        -

        epC;


    const catastrophicFinalPosition =

        epC

        <= 0.18;


    const severeSelfInflictedLoss =

        selfInflictedLoss

        >= 0.18;


    /*
     * Solo bloqueamos Miss
     * cuando ambas cosas ocurren:
     *
     * - acabamos en una posición
     *   prácticamente perdida;
     *
     * - y además estamos claramente
     *   peor que antes del error rival.
     *
     *
     * De esta forma:
     *
     * A 0.20
     * B 0.80
     * C 0.15
     *
     * puede seguir siendo Miss,
     * porque C no es mucho peor
     * que la posición original.
     *
     *
     * Pero:
     *
     * A 0.50
     * B 0.90
     * C 0.05
     *
     * será Blunder.
     */
    if (

        catastrophicFinalPosition

        &&

        severeSelfInflictedLoss

    ) {

        return false;
    }


    /*
     * ========================================================
     * STEP 4
     * MISS CONFIRMED
     * ========================================================
     *
     * Ya no utilizamos
     * retention <= 0.35
     * como filtro rígido.
     *
     * Si:
     *
     * - el rival nos dio
     *   una oportunidad importante;
     *
     * - llegamos a zona ganadora;
     *
     * - perdimos una cantidad
     *   significativa de esa oportunidad;
     *
     * - y nuestra jugada no fue
     *   una catástrofe independiente;
     *
     * entonces clasificamos Miss.
     */

    return true;
}