import {
    WHITE
} from "chess.js";

import {
    ExtractedCurrentNode,
    ExtractedPreviousNode
} from "../types/ExtractedNode";

import {
    Classification
} from "@/constants/Classification";

import {
    adaptPieceColour
} from "@/constants/PieceColour";

import {
    getExpectedPointsLoss
} from "../expectedPoints";


/*
 * ============================================================
 * CLASSIFICATION V2
 * BASED ON EXPECTED POINTS LOSS
 * ============================================================
 *
 *
 * BEST
 *
 * top move
 * OR
 * EP loss <= 0.001
 *
 *
 * EXCELLENT
 *
 * 0.001 < EP loss <= 0.02
 *
 *
 * GOOD
 *
 * 0.02 < EP loss <= 0.05
 *
 *
 * INACCURACY
 *
 * 0.05 < EP loss <= 0.10
 *
 *
 * MISTAKE
 *
 * 0.10 < EP loss <= 0.20
 *
 *
 * BLUNDER
 *
 * EP loss > 0.20
 */


/**
 * Classify a move using
 * Expected Points Loss.
 *
 * Mate transitions keep their
 * specialised WintrChess treatment
 * because Expected Points alone
 * collapses mate evaluations
 * too aggressively.
 */
export function pointLossClassify(
    previous:
        ExtractedPreviousNode,

    current:
        ExtractedCurrentNode
) {

    const previousSubjectiveValue =

        previous
            .evaluation
            .value

        *

        (
            current
                .playedMove
                .color
            == WHITE

                ? 1
                : -1
        );


    const subjectiveValue =

        current
            .subjectiveEvaluation
            .value;


    /*
     * ========================================================
     * MATE -> MATE
     * ========================================================
     */

    if (

        previous
            .evaluation
            .type
        == "mate"

        &&

        current
            .evaluation
            .type
        == "mate"

    ) {

        /*
         * Winning mate
         * becomes losing mate.
         */
        if (

            previousSubjectiveValue
            > 0

            &&

            subjectiveValue
            < 0

        ) {

            return (

                subjectiveValue
                < -3

                    ? Classification.MISTAKE

                    : Classification.BLUNDER

            );
        }


        /*
         * Difference in mate distance.
         */
        const mateLoss =

            (

                current
                    .evaluation
                    .value

                -

                previous
                    .evaluation
                    .value

            )

            *

            (
                current
                    .playedMove
                    .color
                == WHITE

                    ? 1
                    : -1
            );


        /*
         * Losing side maintaining
         * the same forced mate
         * is effectively Best.
         */
        if (

            mateLoss < 0

            ||

            (

                mateLoss == 0

                &&

                subjectiveValue < 0

            )

        ) {

            return Classification.BEST;
        }


        if (
            mateLoss < 2
        ) {

            return Classification.EXCELLENT;
        }


        if (
            mateLoss < 7
        ) {

            return Classification.OKAY;
        }


        return Classification.INACCURACY;
    }


    /*
     * ========================================================
     * MATE -> CENTIPAWN
     * ========================================================
     */

    if (

        previous
            .evaluation
            .type
        == "mate"

        &&

        current
            .evaluation
            .type
        == "centipawn"

    ) {

        if (
            subjectiveValue >= 800
        ) {

            return Classification.EXCELLENT;
        }


        if (
            subjectiveValue >= 400
        ) {

            return Classification.OKAY;
        }


        if (
            subjectiveValue >= 200
        ) {

            return Classification.INACCURACY;
        }


        if (
            subjectiveValue >= 0
        ) {

            return Classification.MISTAKE;
        }


        return Classification.BLUNDER;
    }


    /*
     * ========================================================
     * CENTIPAWN -> MATE
     * ========================================================
     */

    if (

        previous
            .evaluation
            .type
        == "centipawn"

        &&

        current
            .evaluation
            .type
        == "mate"

    ) {

        /*
         * Encontrar un mate ganador.
         */
        if (
            subjectiveValue > 0
        ) {

            return Classification.BEST;
        }


        /*
         * Permitir mate inmediato.
         */
        if (
            subjectiveValue >= -2
        ) {

            return Classification.BLUNDER;
        }


        if (
            subjectiveValue >= -5
        ) {

            return Classification.MISTAKE;
        }


        return Classification.INACCURACY;
    }


    /*
     * ========================================================
     * CENTIPAWN -> CENTIPAWN
     * ========================================================
     *
     * Classification V2.
     */

    const pointLoss =

        getExpectedPointsLoss(

            previous
                .evaluation,

            current
                .evaluation,

            adaptPieceColour(
                current
                    .playedMove
                    .color
            )

        );


    /*
     * BEST.
     *
     * Esto cubre el caso señalado
     * por Gemini:
     *
     * segunda línea prácticamente
     * equivalente a la primera.
     *
     * topMovePlayed también se
     * comprueba posteriormente
     * en classify.ts.
     */
    if (
        pointLoss <= 0.001
    ) {

        return Classification.BEST;
    }


    /*
     * EXCELLENT.
     */
    if (
        pointLoss <= 0.02
    ) {

        return Classification.EXCELLENT;
    }


    /*
     * GOOD.
     */
    if (
        pointLoss <= 0.05
    ) {

        return Classification.OKAY;
    }


    /*
     * INACCURACY.
     */
    if (
        pointLoss <= 0.10
    ) {

        return Classification.INACCURACY;
    }


    /*
     * MISTAKE.
     */
    if (
        pointLoss <= 0.20
    ) {

        return Classification.MISTAKE;
    }


    /*
     * BLUNDER.
     */
    return Classification.BLUNDER;
}